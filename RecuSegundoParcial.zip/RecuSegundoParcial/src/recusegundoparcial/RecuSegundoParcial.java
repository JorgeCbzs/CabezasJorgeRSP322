/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recusegundoparcial;

import java.util.List;
import model.Almacenable;
import model.Inventario;
import model.RobotMarte;
import model.TipoRobot;

/**
 *
 * @author jorge
 */
public class RecuSegundoParcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Almacenable<RobotMarte> inv = new Inventario<>();
            inv.agregar(new RobotMarte(101, "Ares-1", TipoRobot.RECOLECTOR, 85, 2019,
                    123.5));
            inv.agregar(new RobotMarte(102, "Vulcan-7", TipoRobot.SENSORIAL, 85, 2020,
                    188.2));
            inv.agregar(new RobotMarte(103, "GeoMax", TipoRobot.GEOLOGICO, 25, 2017,
                    210.4));
            inv.agregar(new RobotMarte(104, "TopoTrack", TipoRobot.TOPOGRAFICO, 77, 2021,
                    156.0));
            inv.agregar(new RobotMarte(105, "HelperX", TipoRobot.ASISTENCIA, 50, 2018,
                    95.3));
            inv.agregar(new RobotMarte(106, "Ares-2", TipoRobot.RECOLECTOR, 33, 2016,
                    178.9));

            
            System.out.println("=== Inventario Original ===");

            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
            }
            // 1) Orden natural -Listo
            inv.ordenar();
            System.out.println("\n=== Orden Natural ===");
            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
            }

            // 2) Ordenar por nombre → completar Comparator - Listo
            inv.ordenar((r1, r2) -> r1.getNombre().compareTo(r2.getNombre()));
            System.out.println("\n=== Ordenados por Nombre ===");
            for (RobotMarte r : inv.obtenerTodos()) {
                System.out.println(r);
            }

            // 3) Filtrar robots con batería < 30 → completar Predicate
            System.out.println("\n=== Robots con Batería < 30% ===");
            List<RobotMarte> criticos = inv.filtrar(r -> r.getNivelBateria() < 30);
            for (RobotMarte r : criticos) {
                System.out.println(r);
            }

            // 4) Transformar RECOLECTOR → +20% km → completar Function
            System.out.println("\n=== Transformación RECOLECTORES ===");
            List<RobotMarte> transformados = inv.transformar(robot -> {
                if (robot.getTipo() == TipoRobot.RECOLECTOR) {
                    double nuevosKm = robot.getKmRecorridos() * 1.20;
                    return new RobotMarte(robot.getId(), robot.getNombre(), robot.getTipo(),
                            robot.getNivelBateria(), robot.getAnioFabricacion(), nuevosKm);
                }
                return robot;
            });
            for (RobotMarte r : transformados) {
                System.out.println(r);
            }

            // 5) Contar robots fabricados antes de 2018 → completar Predicate
            int antiguos = inv.contar(r -> r.getAnioFabricacion() < 2018);
            System.out.println("\nRobots fabricados antes de 2018: " + antiguos);

            // Persistencias
            inv.guardarEnBinario("src/data/robots.bin");
            inv.guardarEnCSV("src/data/robots.csv");

            
            // Carga desde CSV
            Almacenable<RobotMarte> invCSV = new Inventario<>();
            invCSV.cargarDesdeCSV("src/data/robots.csv", RobotMarte::fromCSV);
            System.out.println("\n=== Inventario cargado desde CSV ===");
            for (RobotMarte r : invCSV.obtenerTodos()) {
                System.out.println(r);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}


