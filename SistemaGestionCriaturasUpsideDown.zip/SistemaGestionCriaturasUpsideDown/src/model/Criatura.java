/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;

/**
 *
 * @author jorge
 */
public class Criatura implements Comparable <Criatura>, CSVSerializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String origen;
    private TipoCriatura tipo;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipo) {
        
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipo = tipo;
    }

    
    @Override
    public int compareTo(Criatura o) {
        return Integer.compare(id, o.id);
        
    }
    
    @Override
    public String toString() {
        return "Criatura" + "ID: " + id + "Nombre: " + nombre + "Origen: " + origen + "Tipo: " + tipo;
    }
    
    
    
    @Override
    public String toCSV (){
        return id + "," + nombre + "," + origen + "," + tipo;
    }
    
    
    public static Criatura fromCSV(String linea){
        String [] partes = linea.split(",");
        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String origen = partes [2];
        TipoCriatura tipo = TipoCriatura.valueOf(partes[3]);
        
        return new Criatura(id,nombre,origen,tipo);
    }

    public int getId() {
        return id;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipo() {
        return tipo;
    }
    
    
    
    
    
    
}
