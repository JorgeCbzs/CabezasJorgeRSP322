/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author jorge
 */
public class Inventario<T extends CSVConvertible & Comparable> implements Almacenable<T>{

    List<T> elementos = new ArrayList<>();
    
    @Override
    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Iterator<T> iterador = elementos.iterator();
        while (iterador.hasNext()) {
            if (criterio.test(iterador.next())) {
                iterador.remove();
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        List<T> nuevaLista = new ArrayList<>(elementos);
        
        return nuevaLista;
        
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        for (T item : elementos) {
            if (criterio.test(item)) {
                return item;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
        Collections.sort(elementos);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        Collections.sort(elementos, comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for (T item : elementos) {
            if (criterio.test(item)) {
                listaFiltrada.add(item);
            }
        }
        return listaFiltrada;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        List<T> listaTransformada = new ArrayList<>();
        for (T item : elementos) {
            listaTransformada.add(operador.apply(item));
        }
        return listaTransformada;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        int contador = 0;
        for (T item : elementos) {
            if (criterio.test(item)) {
                contador++;
            }
        }
        return contador;
    }

    
    
    
    
    @Override
    public void guardarEnBinario(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(elementos);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        elementos.clear();
        try (ObjectInputStream desearializador = new ObjectInputStream(new FileInputStream(path))) {
            elementos = (List<T>) desearializador.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write(RobotMarte.toHeaderCSV());
            
            for (T elemento : elementos) {
                escritor.write(elemento.toCSV());
                escritor.newLine();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
    @Override
    public void cargarDesdeCSV(String path, Function<String, T> transformacion) throws IOException {
        elementos.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null) {
                elementos.add(transformacion.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    
    
    
    
    @Override
    public void guardarEnJSON(String ruta) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
