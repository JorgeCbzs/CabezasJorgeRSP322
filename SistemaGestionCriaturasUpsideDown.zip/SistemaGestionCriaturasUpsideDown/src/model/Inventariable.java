/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author jorge
 */
public interface Inventariable<T extends CSVSerializable & Comparable<T>> extends Iterable {

    void agregar(T item);

    T obtener(int indice);

    void eliminar(int indice);

    void paraCadaElemento(Consumer<T> accion);

    List<T> filtrar(Predicate<T> criterio);

    void ordenar();

    void ordenar(Comparator<? super T> comp);

}
