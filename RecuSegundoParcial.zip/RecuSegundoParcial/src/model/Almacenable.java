/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author jorge
 */
public interface Almacenable<T> {

    
    //OPERACIONES BASICAS
    void agregar(T elemento);

    void eliminarSegun(Predicate<T> criterio);

    List<T> obtenerTodos();

    T buscar(Predicate<T> criterio);

    
    
    //PROCESAMIENTO
    void ordenar();

    void ordenar(Comparator<T> comparador);

    List<T> filtrar(Predicate<T> criterio);

    List<T> transformar(Function<T, T> operador);

    int contar(Predicate<T> criterio);

    
    //PERSISTENCIA
    void guardarEnBinario(String ruta) throws Exception;

    void cargarDesdeBinario(String ruta) throws Exception;

    void guardarEnCSV(String ruta) throws Exception;

    void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception;

    void guardarEnJSON(String ruta) throws Exception;

}
